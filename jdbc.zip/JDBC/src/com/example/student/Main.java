package com.example.student;

public class Main {
    public static void main(String[] args) {
        StudentDAO studentDAO = new StudentDAO();

        // Insert students
        studentDAO.insertStudent("John Doe", "New York", "Computer Science", "1234567890");
        studentDAO.insertStudent("Jane Smith", "Los Angeles", "Mathematics", "0987654321");

        // Get all students
        System.out.println("All Students:");
        studentDAO.getAllStudents();

        // Update student details
        studentDAO.updateStudent(1, "San Francisco", "Data Science");

        // Get all students after update
        System.out.println("\nAll Students After Update:");
        studentDAO.getAllStudents();

        // Delete student by ID
        studentDAO.deleteStudent(2);

        // Get all students after delete
        System.out.println("\nAll Students After Delete:");
        studentDAO.getAllStudents();
    }
}
