package com.example.student;

import java.sql.*;

public class StudentDAO {

    // Insert student details into the table
    public void insertStudent(String name, String place, String course, String contactNum) {
        String query = "INSERT INTO Student (Student_name, Student_place, Course, Contact_num) VALUES (?, ?, ?, ?)";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, name);
            statement.setString(2, place);
            statement.setString(3, course);
            statement.setString(4, contactNum);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Student inserted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Get all the student details from the student table
    public void getAllStudents() {
        String query = "SELECT * FROM Student";

        try (Connection connection = DBConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                int id = resultSet.getInt("Student_id");
                String name = resultSet.getString("Student_name");
                String place = resultSet.getString("Student_place");
                String course = resultSet.getString("Course");
                String contact = resultSet.getString("Contact_num");

                System.out.println("ID: " + id + ", Name: " + name + ", Place: " + place + ", Course: " + course + ", Contact: " + contact);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update student details (by Student_id)
    public void updateStudent(int id, String newPlace, String newCourse) {
        String query = "UPDATE Student SET Student_place = ?, Course = ? WHERE Student_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, newPlace);
            statement.setString(2, newCourse);
            statement.setInt(3, id);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Student updated successfully!");
            } else {
                System.out.println("Student not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete student from table by Student_id
    public void deleteStudent(int id) {
        String query = "DELETE FROM Student WHERE Student_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, id);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Student deleted successfully!");
            } else {
                System.out.println("Student not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

